# Environments

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Required environments

### Local
Developer implementation/debugging.

### Development / Preview
Shared or ephemeral integration environment.

### Staging
Production-like release verification.

### Production
Live system.

## Separation

Each non-local environment should have separate:
- database
- storage namespace/bucket
- secrets
- site/API/CMS origin as applicable

Never point local/staging at production writable data by default.

## Data policy

Do not copy production data to lower environments unless sanitized and approved.
