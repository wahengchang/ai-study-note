# Backup & Restore

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Back up
1. Database
2. Object storage/media
3. Deployment/config definitions
4. Secret recovery procedure via approved secret manager/operator process

## Database policy must define
- frequency
- retention
- encryption
- off-system copy
- restore procedure

## Storage policy must define
- versioning if available
- backup/replication
- deletion protection
- retention

## Restore test

A backup is not reliable until restoration is tested.

Minimum drill:
1. Provision isolated environment.
2. Restore database.
3. Restore/access media.
4. Start app.
5. Verify representative content and CMS records.
6. Record outcome and recovery time.

## Decision required

Set explicit RPO/RTO before production launch.
