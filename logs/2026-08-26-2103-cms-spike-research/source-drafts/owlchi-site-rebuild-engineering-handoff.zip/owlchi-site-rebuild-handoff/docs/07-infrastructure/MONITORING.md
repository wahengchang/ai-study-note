# Monitoring

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Minimum signals

### Availability
- Public website reachable
- API reachable
- CMS reachable for authorized staff

### Application
- Error rate
- Request latency
- Failed auth spikes
- Failed uploads
- Background jobs if later added

### Infrastructure
- Database health/connections
- Storage errors
- Resource pressure where applicable

## Logs

Structured logs should include:
- timestamp
- level
- request/correlation ID
- component
- message
- safe context

Never log passwords, session secrets, access tokens or unnecessary confidential payloads.

## Launch alerts
- sustained 5xx rate
- site unavailable
- database unavailable
- storage upload failures
- backup failures
