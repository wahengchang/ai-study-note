# Configuration

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Principles
- Safe defaults may live in code.
- Environment-specific values live in config/environment.
- Secrets never enter Git.
- `.env.example` lists required keys without real secrets.

## Expected categories

```text
APP
PUBLIC_SITE_URL
CMS_URL
API_URL

DATABASE
DATABASE_URL

STORAGE
STORAGE_ENDPOINT
STORAGE_BUCKET
STORAGE_REGION
STORAGE_ACCESS_KEY
STORAGE_SECRET_KEY
PUBLIC_MEDIA_BASE_URL

AUTH
SESSION_SECRET

OBSERVABILITY
LOG_LEVEL
ERROR_TRACKING_*   [if selected]
```

Names are illustrative.

## CMS vs environment

CMS-editable:
- site name
- default SEO
- public contact/social info

Environment-only:
- credentials
- signing secrets
- database URL
- privileged storage values
