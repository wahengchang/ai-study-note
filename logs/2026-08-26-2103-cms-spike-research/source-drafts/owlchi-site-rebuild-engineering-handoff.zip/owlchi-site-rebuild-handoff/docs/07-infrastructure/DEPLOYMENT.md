# Deployment

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Target flow

```text
Merge approved change
  ↓
CI
  ├── install
  ├── lint/typecheck
  ├── tests
  └── build
  ↓
Deploy
  ↓
Run/verify migrations
  ↓
Smoke test
  ↓
Release complete
```

## Potential deployment units
- Public Website
- CMS
- Backend API

They may deploy together or separately; Decision Required.

## Production release requirements
- CI passes
- migrations reviewed
- configuration present
- backup state understood
- rollback path known
- smoke test defined

## Migration policy
- committed
- ordered/reproducible
- tested
- destructive changes require rollout/recovery plan

## Rollback

Application rollback should be possible where schema compatibility allows. Destructive migrations require explicit recovery planning.
