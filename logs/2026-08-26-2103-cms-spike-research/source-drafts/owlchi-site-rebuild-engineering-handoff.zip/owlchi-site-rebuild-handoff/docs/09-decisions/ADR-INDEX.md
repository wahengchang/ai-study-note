# Architecture Decision Record Index

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Create an ADR when a decision materially affects
- system boundaries
- data model
- deployment
- security
- storage
- API contracts
- long-term operational cost

## Planned decisions

| ADR | Topic | Status |
|---|---|---|
| ADR-0001 | Application boundaries | Proposed |
| ADR-0002 | Relational database | Decision Required |
| ADR-0003 | Object storage | Decision Required |
| ADR-0004 | Authentication | Decision Required |
| ADR-0005 | Public rendering strategy | Decision Required |

Do not invent a provider choice just to close an ADR.
