# ADR-0001 — Application Boundaries

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Status
Proposed

## Context

The product needs a public website, internal CMS, backend logic, database and storage. Public delivery and administrative writes have different security and UX concerns.

## Decision

Maintain explicit logical boundaries:

```text
Public Website
CMS
Backend/API
Database
Object Storage
```

Website and CMS access persistent data through backend-defined contracts rather than writing directly to persistence.

Deployment may combine components initially, but responsibilities remain distinct.

## Consequences

Positive:
- clearer security
- centralized business rules
- easier testing
- frontend/CMS can evolve independently

Tradeoff:
- more explicit API/service structure than direct database access
