# Authentication & Authorization

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Model

```text
Request
  ↓
Authentication
  ↓
Current User
  ↓
Roles
  ↓
Permissions
  ↓
Resource Action Allowed?
```

## Authentication — Decision Required

Potential approaches:
- Session cookie
- Token
- External identity provider

For browser-only CMS, secure HTTP-only sessions are a strong default when architecture supports them.

## Authorization

Examples:
- `page.create`
- `page.update`
- `page.publish`
- `article.delete`
- `media.upload`
- `navigation.manage`
- `user.manage`

## Enforcement

Authorization happens:
1. In backend/API for security.
2. In CMS UI for usability.

UI hiding alone is not security.

## Baseline
- Modern password hashing if local passwords are used
- Login rate limiting
- CSRF protection where applicable
- Secure production cookies
- Least privilege
- No client-side secrets
- Audit important admin actions
