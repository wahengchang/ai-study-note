# API Endpoints — Proposed Surface

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

This describes capabilities, not locked URLs.

## Public

Possible examples:

```text
GET /api/public/pages/:slug
GET /api/public/articles
GET /api/public/articles/:slug
GET /api/public/categories/:slug/articles
GET /api/public/search?q=
GET /api/public/navigation
```

## Admin — pages/articles

```text
GET    /api/admin/pages
POST   /api/admin/pages
GET    /api/admin/pages/:id
PATCH  /api/admin/pages/:id
DELETE /api/admin/pages/:id

POST   /api/admin/pages/:id/publish
POST   /api/admin/pages/:id/unpublish
```

Equivalent capabilities apply to articles.

## Admin — taxonomy
- Category CRUD
- Tag CRUD

## Admin — media

```text
GET    /api/admin/media
POST   /api/admin/media
PATCH  /api/admin/media/:id
DELETE /api/admin/media/:id
```

## Admin — platform
- Navigation CRUD
- User CRUD
- Role/permission management
- Settings read/update

## Contract requirements
- Pagination for unbounded lists
- Documented filters/sorting
- Stable validation errors
- Explicit publish action
- Explicit deletion semantics
