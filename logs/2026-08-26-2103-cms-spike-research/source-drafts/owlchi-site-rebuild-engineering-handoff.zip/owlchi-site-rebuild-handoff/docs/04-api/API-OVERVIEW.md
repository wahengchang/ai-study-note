# API Overview

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Consumers

```text
Public Website ──> Public API
CMS            ──> Admin API
```

They may run in one backend while preserving different access policies.

## Public API

- Read-only
- Published content only
- Minimal payloads
- Cache-friendly
- Stable pagination
- No internal/admin metadata leakage

## Admin API

- Authenticated
- Permission checked
- Validated
- Auditable for important writes
- Supports CRUD and publication lifecycle

## Error contract

Use one consistent machine-readable format, for example:

```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Validation failed",
    "fields": {
      "slug": "Already in use"
    }
  }
}
```

Exact shape is Decision Required; consistency is mandatory.

## Versioning

Avoid premature versioning. Define a compatibility policy before introducing external consumers or breaking contracts.
