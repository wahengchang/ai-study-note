# CMS Architecture

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Logical flow

```text
Admin User
   ↓
CMS UI
   ↓
Admin API
   ↓
Application Services
   ↓
Database + Storage
```

## Modules

- Authentication
- Dashboard
- Pages
- Articles
- Categories
- Tags
- Media
- Navigation
- SEO
- Users
- Roles/permissions
- Settings

## Rules

1. UI visibility is permission-aware.
2. Backend authorization remains mandatory.
3. Edit forms load canonical data from API.
4. Save and publish are separate concepts.
5. Destructive actions require confirmation.
6. Slug conflicts are validated.
7. Media deletion accounts for references.
8. Validation errors are actionable in forms.

## Proposed content states

```text
New → Draft → Published
             ↘ Archived

Published → Unpublished/Draft
```
