# Frontend Architecture

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Scope

Public website only.

## Proposed layers

```text
Routes / Pages
    ↓
Page Composition
    ↓
Domain Components
    ↓
Shared UI
    ↓
API Client
```

### Routes
Map public URLs to content types/templates.

### Page composition
Combine layout, content, media and SEO.

### Domain components
Examples: ArticleCard, ArticleHeader, CategoryList, RichContent, Media, Breadcrumbs.

### Shared UI
Examples: Button, Link, Container, Header, Footer, Pagination.

### API client
One abstraction for backend access; do not scatter raw HTTP calls across UI components.

## Rendering requirements

- Crawlable HTML
- Fast first render
- Stable canonical URLs
- Metadata from content records
- Correct 404 behavior
- Responsive images/layout

## State guidance

Prefer backend/API state. Avoid global client state unless a feature needs it.

## Security

- No admin-only fields in public payloads
- Sanitize/escape authored rich content
- No secrets in frontend bundles
