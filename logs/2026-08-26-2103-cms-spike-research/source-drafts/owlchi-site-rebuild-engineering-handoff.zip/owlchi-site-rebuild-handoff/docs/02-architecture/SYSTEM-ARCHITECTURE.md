# System Architecture

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Logical architecture

```text
                    ┌───────────────────┐
                    │      Visitor      │
                    └─────────┬─────────┘
                              │ HTTPS
                              ▼
                    ┌───────────────────┐
                    │  Public Website   │
                    └─────────┬─────────┘
                              │
                              ▼
                    ┌───────────────────┐
                    │   Backend / API   │
                    └──────┬─────┬──────┘
                           │     │
                structured │     │ binary
                      data │     │ files
                           ▼     ▼
                  ┌──────────┐ ┌──────────────┐
                  │ Database │ │Object Storage│
                  └────▲─────┘ └──────▲───────┘
                       │              │
                       └──────┬───────┘
                              │
                    ┌─────────┴─────────┐
                    │      CMS/Admin    │
                    └─────────▲─────────┘
                              │
                       Editor / Admin
```

## Responsibilities

### Public Website
- Render public/published content
- Resolve routes/slugs
- Present media
- Emit SEO metadata
- Handle 404/redirects

### CMS
- Authenticate staff
- Manage structured content/media
- Manage publication state
- Manage navigation, SEO and settings
- Provide permission-aware UI

### Backend / API
- Validate requests
- Enforce authorization
- Apply business rules
- Read/write database
- Coordinate storage
- Expose stable contracts

### Database
Stores structured content, identities, navigation, SEO, media metadata and settings.

### Object Storage
Stores images, documents and other binary assets.

## Architectural rules

1. CMS does not write directly to the database.
2. Public frontend does not write directly to the database.
3. Draft content never leaks through public endpoints.
4. Authorization is server-side, not only UI.
5. Schema changes require migrations.
6. Storage vendor URLs should not become the only media identity.

## Technology status

Frameworks/providers/hosting are Decision Required.
