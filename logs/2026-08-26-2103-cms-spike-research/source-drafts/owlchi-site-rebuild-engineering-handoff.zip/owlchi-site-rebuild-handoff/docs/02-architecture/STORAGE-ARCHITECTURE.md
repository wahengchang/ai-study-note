# Storage Architecture

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Storage role

```text
Database media record
├── id
├── filename
├── mime_type
├── size
├── storage_key
├── dimensions
└── alt_text
        │
        ▼
Object Storage
└── actual binary bytes
```

## V1

At minimum:
- Images
- PDFs/documents if required

Video transcoding/streaming is out of scope unless separately approved.

## Required operations

- Upload
- Deliver/read
- Delete
- Validate size/type
- Record metadata
- Prevent unsafe key/path construction

## Recommended key style

```text
media/YYYY/MM/<uuid>/<normalized-file-name>
```

Use generated immutable identities instead of relying on original filenames.

## Decision required

Choose public delivery:
- Direct storage
- CDN
- Application proxy
- Signed/private URLs
