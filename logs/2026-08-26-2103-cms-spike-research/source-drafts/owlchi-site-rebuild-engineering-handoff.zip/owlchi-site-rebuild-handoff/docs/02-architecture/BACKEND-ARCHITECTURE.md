# Backend Architecture

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Proposed layers

```text
HTTP / API Layer
      ↓
Authentication + Validation
      ↓
Authorization
      ↓
Application Services
      ↓
Repositories / Data Access
      ↓
Database / Storage Adapters
```

## API layer
Responsible for routing, request/response mapping and authentication context.

## Application services
Own business behavior such as:
- Create article
- Publish/unpublish page
- Replace media
- Build navigation tree
- Manage permissions

Do not bury business rules in controllers or database models.

## Data access
Owns queries, transactions, pagination and persistence mapping.

## Storage adapter
Owns upload, delete, metadata inspection and delivery URL logic.

## Public vs admin boundary

Even if one backend serves both:

```text
/api/public/*
/api/admin/*
```

Keep authorization policies explicit.
