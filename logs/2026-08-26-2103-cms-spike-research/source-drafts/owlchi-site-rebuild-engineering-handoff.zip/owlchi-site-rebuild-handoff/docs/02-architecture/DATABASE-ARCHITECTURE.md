# Database Architecture

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Database role

The relational database stores structured records and relationships. Large binary media bodies belong in object/file storage.

## Core domains

```text
Identity
├── users
├── roles
├── permissions
├── user_roles
└── role_permissions

Content
├── pages
├── articles
├── categories
├── tags
├── article_tags
└── navigation_items

Media
└── media

Configuration
└── settings
```

## Requirements

- Transactions
- Foreign keys
- Unique constraints where required
- Committed migrations
- Created/updated timestamps
- Appropriate indexes
- Backups with tested restore

## Publication safety

All public content queries must share a reliable publication filter.

## Source of truth

Executable migrations/schema become the implementation source of truth after development begins. Keep this document aligned conceptually.
