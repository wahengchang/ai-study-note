# File Storage Model

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Separation

```text
Media record = identity + meaning + metadata
Storage object = bytes
```

## Lifecycle

```text
Upload
  ↓
Validate
  ↓
Store object
  ↓
Create media record
  ↓
Attach to content
  ↓
Deliver
```

## Validation

Check:
- MIME type
- extension consistency
- maximum size
- image dimensions if needed
- corrupt/empty uploads
- filename normalization

## Deletion

1. Check references.
2. If referenced, block or explicitly detach.
3. Delete storage object.
4. Delete/archive media record.
5. Log important operation.

## Recommended metadata

- checksum where useful
- MIME type
- byte size
- dimensions
- original filename
- storage key
- uploader
- created time
- alt text
- caption
