# Data Model

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## High-level relationships

```text
User ──< Content(author)

Page
 ├── Media
 └── SEO metadata

Article
 ├── Category
 ├── Tags
 ├── Media
 └── SEO metadata

Navigation
 └── NavigationItem
      └── Page / Article / URL

Media
 └── Object Storage key
```

## Shared publishable fields

Conceptually:
- id
- title
- slug
- status
- summary where relevant
- body/content
- SEO title/description
- social image
- published_at
- created_at / updated_at
- created_by / updated_by where useful

## Identifier rule

Internal IDs and public slugs are different concerns. Do not use mutable slugs as primary keys.

## Deletion rule

For referenced records/files, define explicit behavior: block, detach, archive or cascade only when semantically safe.
