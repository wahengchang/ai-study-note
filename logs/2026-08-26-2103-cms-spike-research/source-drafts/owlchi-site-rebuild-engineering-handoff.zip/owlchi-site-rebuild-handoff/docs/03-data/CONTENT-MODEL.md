# Content Model

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Page

For relatively stable route-oriented content.

Examples:
- About
- Contact
- Service landing page

Core fields:
- Title
- Slug
- Body/content
- Status
- SEO
- Optional cover/social media
- Published timestamp

## Article

For chronological/editorial content.

Core fields:
- Title
- Slug
- Summary
- Body
- Category
- Tags
- Cover media
- Status
- Publish timestamp
- SEO

## Category
Primary grouping for articles: name, slug, description.

## Tag
Secondary many-to-many classification: name, slug.

## Media
Reusable file metadata linked to object storage.

## Navigation
Ordered tree of labels and targets. Targets may be internal content or external URLs.

## SEO
Per publishable item:
- SEO title
- Meta description
- Canonical override
- Social image
- Optional indexability override

## Status

Proposed V1:
- draft
- published
- archived

Potential future:
- scheduled
- review
