# Database Schema — Proposed V1

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

This is a conceptual planning schema. Final names/types belong in migrations.

## users
- id
- email — unique
- password_hash or external identity reference
- display_name
- status
- created_at
- updated_at

## roles
- id
- name — unique
- description

## permissions
- id
- key — unique
- description

## user_roles
- user_id
- role_id

## role_permissions
- role_id
- permission_id

## pages
- id
- title
- slug
- summary
- body
- status
- cover_media_id — nullable
- seo_title
- seo_description
- canonical_url — nullable
- published_at — nullable
- created_by
- updated_by
- created_at
- updated_at

## articles
Same base fields as pages plus:
- category_id
- optional author/display metadata

## categories
- id
- name
- slug
- description
- timestamps

## tags
- id
- name
- slug
- timestamps

## article_tags
- article_id
- tag_id
- composite uniqueness

## media
- id
- filename
- storage_key — unique
- mime_type
- size_bytes
- width — nullable
- height — nullable
- alt_text
- caption
- created_by
- timestamps

## navigation_items
- id
- parent_id — nullable
- label
- type
- target
- position
- is_enabled

## settings
- key — unique
- value
- updated_at

## Index candidates

- page/article slug
- page/article status + published_at
- article category_id + published_at
- category/tag slug
- navigation parent_id + position
- media created_at

## Decision required

- Rich text storage format
- Localization model
- Revision history
- Soft delete
- Search indexing
