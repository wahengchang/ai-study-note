# Reference Product Inventory

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

Use this after access to the reference repository/product is available.

Reference:
https://github.com/wahengchang/owlchi-site-system/

## Repository
- Default branch: TBD
- Runtime: TBD
- Package manager: TBD
- Frontend: TBD
- Backend: TBD
- Database: TBD
- Storage: TBD
- Auth: TBD
- Deployment: TBD

## Public routes

| Route | Purpose | Keep / Change |
|---|---|---|
| TBD | TBD | TBD |

## CMS screens

| Screen | Capability | Keep / Change |
|---|---|---|
| TBD | TBD | TBD |

## Data entities

| Entity | Key fields | Migration need |
|---|---|---|
| TBD | TBD | TBD |

## External dependencies

| Service | Purpose | Reuse? |
|---|---|---|
| TBD | TBD | TBD |

## Reuse classification

For each subsystem choose:
- Reuse as-is
- Refactor and reuse
- Reimplement
- Remove

Always record the reason.
