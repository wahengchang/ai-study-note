# Current State

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Project phase

**Product/architecture definition — before implementation.**

## Defined

| Area | Status |
|---|---|
| Product boundary | ✅ Defined |
| Public capabilities | ✅ V1 defined |
| CMS capabilities | ✅ V1 defined |
| Logical architecture | ✅ Defined |
| Content model | ✅ Proposed |
| API surface | ✅ Proposed |
| Roles/permissions | ✅ Proposed |
| Database responsibility | ✅ Defined |
| Storage responsibility | ✅ Defined |
| Deployment expectations | ✅ Conceptual |
| Handoff structure | ✅ Defined |

## Not yet verified/selected

| Area | Status |
|---|---|
| Reference repo implementation | ⚠️ Not inspected |
| Frontend framework | ❓ Decision Required |
| Backend framework | ❓ Decision Required |
| Database product | ❓ Decision Required |
| ORM/query layer | ❓ Decision Required |
| Object storage provider | ❓ Decision Required |
| Authentication | ❓ Decision Required |
| Hosting | ❓ Decision Required |
| CI/CD | ❓ Decision Required |
| Production domains | ❓ TBD |

## Progress

```text
Product definition       ██████████  defined
Logical architecture     ██████████  defined
Technical decisions      ██░░░░░░░░  pending
Repository scaffold      ░░░░░░░░░░  not started
Database implementation  ░░░░░░░░░░  not started
Backend/API              ░░░░░░░░░░  not started
CMS                      ░░░░░░░░░░  not started
Public website           ░░░░░░░░░░  not started
Deployment               ░░░░░░░░░░  not started
```

## Next milestone

Resolve blocking decisions, scaffold the repo, then implement the smallest vertical slice:

**CMS login → create article → upload image → publish → view article on public website.**
