# Known Issues & Risks

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

There are no implementation defects yet because implementation has not started.

## RISK-001 — Reference implementation not verified
**Impact:** False parity assumptions.  
**Mitigation:** Inspect reference repo/product before claiming equivalence.

## RISK-002 — Stack undecided
**Impact:** Premature code may cause rework.  
**Mitigation:** Resolve blocking technical decisions and record ADRs.

## RISK-003 — URL migration / SEO
**Impact:** Existing indexed URLs may lose traffic.  
**Mitigation:** Inventory current URLs and define redirects before cutover.

## RISK-004 — Media lifecycle
**Impact:** Deleting referenced files breaks pages.  
**Mitigation:** Reference checks and explicit deletion rules.

## RISK-005 — Draft leakage
**Impact:** Unpublished content becomes public.  
**Mitigation:** Central publication filtering plus integration/E2E tests.
