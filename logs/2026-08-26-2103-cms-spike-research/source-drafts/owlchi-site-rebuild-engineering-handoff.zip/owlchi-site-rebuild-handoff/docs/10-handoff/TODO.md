# Engineering TODO

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## P0 — Before deep implementation
- [ ] Obtain/verify reference repo or running product access
- [ ] Inventory reference behavior
- [ ] Select frontend
- [ ] Select backend/API
- [ ] Select relational database
- [ ] Select ORM/query approach
- [ ] Select object storage
- [ ] Select auth/session approach
- [ ] Select hosting/deployment topology
- [ ] Record major decisions as ADRs

## P0 — Foundation
- [ ] Scaffold repo
- [ ] Add `.env.example`
- [ ] Add local database/storage setup
- [ ] Add migrations
- [ ] Add CI
- [ ] Add structured logging
- [ ] Add health endpoint

## P0 — Vertical slice
- [ ] Admin login
- [ ] Article schema
- [ ] Media schema/storage
- [ ] CMS article form
- [ ] Publish/unpublish
- [ ] Public article API
- [ ] Public article page
- [ ] SEO metadata
- [ ] E2E publish journey

## P1
- [ ] Pages
- [ ] Categories
- [ ] Tags
- [ ] Navigation
- [ ] Users/roles
- [ ] Search
- [ ] Redirects
- [ ] Backup/restore test
- [ ] Monitoring/alerts
