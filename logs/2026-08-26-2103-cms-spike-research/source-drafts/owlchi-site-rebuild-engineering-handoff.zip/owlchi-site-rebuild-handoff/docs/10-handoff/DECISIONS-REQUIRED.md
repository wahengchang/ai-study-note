# Decisions Required Before Implementation

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

These are intentionally unresolved. The engineer should recommend options, record the decision, then implement.

## D1 — Repository topology
Choose monorepo or multiple repositories.

Recommended default: monorepo unless team/deployment constraints strongly favor separation.

## D2 — Public frontend
Select framework, rendering strategy, runtime and package manager.

Must support crawlable SEO-friendly delivery and stable routing.

## D3 — CMS
Choose custom admin app, headless CMS product or shared framework.

Current documents assume a logical custom CMS boundary, not a specific framework.

## D4 — Backend/API
Select framework, API style and deployment shape.

Preserve authorization and application-service boundaries.

## D5 — Relational database
Select product/provider supporting transactions, migrations, backups and mature tooling.

## D6 — Data access
Choose ORM, query builder or direct SQL based on maintainability, migration quality and query visibility.

## D7 — Object storage
Select S3-compatible/cloud-native/self-hosted storage and define public delivery/CDN behavior.

## D8 — Authentication
Choose local auth, managed identity, SSO or hybrid, plus session/token mechanics.

## D9 — Publication workflow
Decide:
- Can Editors publish?
- Is Admin approval required?
- Are edits to published content immediately live?

## D10 — Rich content representation
Choose HTML, Markdown, JSON/block model or hybrid.

This affects CMS editor, database, renderer and sanitization.

## D11 — Search
Choose database search or external search engine.

Start simple unless requirements justify external infrastructure.

## D12 — Hosting / CI/CD
Define environments, hosting, database/storage hosting, CI, secrets and domains.

## D13 — Existing URL migration
If replacing a live site, inventory URLs, identify critical routes and define redirects/canonical behavior.
