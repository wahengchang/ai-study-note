# Engineering Handoff

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## What you are taking over

A new implementation of an Owlchi-like content website platform with public frontend, CMS/admin, backend/API, database and media storage.

## Important truth

Reference repository:

https://github.com/wahengchang/owlchi-site-system/

The codebase was not technically inspected while preparing this package. Treat it as a product/reference target until access is available.

## Read first

1. `../01-product/PRODUCT-OVERVIEW.md`
2. `../01-product/FEATURE-MAP.md`
3. `../02-architecture/SYSTEM-ARCHITECTURE.md`
4. `../03-data/CONTENT-MODEL.md`
5. `CURRENT-STATE.md`
6. `DECISIONS-REQUIRED.md`

## First engineering tasks

### 1. Inspect reference
Record:
- routes
- public behavior
- CMS screens
- entities
- media behavior
- reusable parts

Do not preserve accidental legacy constraints without understanding them.

### 2. Resolve decisions
See `DECISIONS-REQUIRED.md` and record architectural decisions as ADRs.

### 3. Scaffold repository
Create selected topology, local environment and CI.

### 4. Build first vertical slice
1. Admin authentication
2. Article model/migration
3. Media upload
4. CMS article editor
5. Publish endpoint
6. Public article route
7. SEO metadata
8. E2E test

### 5. Expand
Then add pages, taxonomy, navigation, users/roles, search and operational hardening.

## Handoff discipline

When the system changes:
- Update relevant architecture/data/API docs.
- Add ADR for architecture decisions.
- Update `CURRENT-STATE.md`.
- Record actual recurring problems in `KNOWN-ISSUES.md`.
- Keep `TODO.md` focused on next engineering work.

## Good handoff test

A new engineer can answer:
- What are we building?
- What is already done?
- Why is it designed this way?
- How do I run it?
- What is next?
- What can break?
- How do I deploy/recover it?

without depending on oral history.
