# SEO Requirements

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Per-page metadata
- HTML title
- Meta description
- Canonical
- Open Graph title/description/image
- Robots directive where needed

## Site-wide
- XML sitemap
- robots.txt
- Canonical host strategy
- Stable URLs
- Real 404s
- Redirects for migrated URLs
- Structured data when semantically justified

## Article
Recommended:
- title
- published date
- modified date
- author if product uses one
- canonical
- social image

## Indexing rule

Draft, admin and preview content must not be indexable.

## Migration

If replacing an existing live site, inventory important existing URLs and create redirect mappings before cutover.
