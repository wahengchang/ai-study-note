# Public Page Map

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Proposed routes

```text
/
├── /about or other CMS-managed pages
├── /articles
│   ├── /:article-slug
│   ├── /category/:category-slug
│   └── /tag/:tag-slug        [optional V1]
├── /search
└── /<page-slug>              [only if catch-all strategy approved]
```

## Page types
- Home
- Generic Page
- Article Index
- Article Detail
- Category Listing
- Search
- 404
- Generic error

## Decision required

Define route namespace rules before implementation to avoid collisions between generic pages, articles, categories and future features.
