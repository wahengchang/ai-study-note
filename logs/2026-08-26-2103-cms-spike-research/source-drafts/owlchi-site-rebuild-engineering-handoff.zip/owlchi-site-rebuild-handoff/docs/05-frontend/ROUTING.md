# Routing

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Goals
- Human-readable
- Stable
- SEO-safe
- Collision-resistant
- Explicit redirect behavior

## Slugs

Recommended:
- lowercase
- URL-safe
- unique within namespace
- stable after publication

If a published slug changes, preserve important old URLs using redirects.

## Resolution

A request should resolve to exactly one content type. Avoid ambiguous catch-all routes without a precedence rule.

## 404

Missing or unpublished content returns a real 404 response, not a 200 page that says "not found."

## Redirect model — P1

Potential fields:
- source path
- destination path
- HTTP status
- enabled flag
- timestamps
