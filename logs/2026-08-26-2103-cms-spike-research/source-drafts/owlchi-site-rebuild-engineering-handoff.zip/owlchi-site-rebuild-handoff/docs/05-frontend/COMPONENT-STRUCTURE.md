# Component Structure

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Proposed hierarchy

```text
App Shell
├── Header
│   └── Navigation
├── Main
│   ├── Page Template
│   ├── Article Template
│   ├── Listing Template
│   └── Search Template
└── Footer
```

## Categories

### Layout
Container, grid/stack, Header, Footer.

### Content
RichContent, ArticleCard, ArticleHeader, CategoryBadge, TagList, Breadcrumbs.

### Media
ResponsiveImage, FileLink, Figure/Caption.

### Interaction
Pagination, SearchForm, MobileNavigation.

## Rule

Prefer components representing reusable product concepts. Do not over-abstract one-off markup.

## CMS sharing

Share primitives only when useful. Do not couple public design unnecessarily to internal CMS UI.
