# CMS Features

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Dashboard
- Status overview
- Recent content
- Useful shortcuts
- Operational alerts if available

## Pages / Articles
- List/filter
- Create
- Edit
- Preview
- Publish/unpublish
- Archive/delete based on policy

Articles additionally use category/tags.

## Media
- Upload
- Browse/search/filter
- Edit alt/caption
- Select in content forms
- Safe deletion

## Navigation
- Create/edit
- Order
- Parent/child hierarchy
- Enable/disable
- Internal/external targets

## SEO
- Per-content metadata
- Site defaults

## Users / Roles
- List/create/invite according to auth model
- Activate/deactivate
- Assign roles
- View/manage permissions per policy

## Settings
Appropriate examples:
- Site name
- Default SEO
- Public contact/social data

Do not expose arbitrary infrastructure secrets as CMS settings.
