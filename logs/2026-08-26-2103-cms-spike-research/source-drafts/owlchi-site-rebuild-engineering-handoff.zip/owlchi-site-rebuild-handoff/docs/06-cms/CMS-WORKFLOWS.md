# CMS Workflows

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Create content

```text
Open CMS
  ↓
Create Page/Article
  ↓
Enter required fields
  ↓
Save Draft
  ↓
Preview
  ↓
Publish
```

## Edit published content

```text
Open Published Item
  ↓
Edit
  ↓
Validate
  ↓
Save / Publish Updated Version
```

Decision Required:
- published edits immediately live
- separate draft copy
- versioned publish workflow

## Upload media

```text
Choose file
  ↓
Client basic validation
  ↓
Server validation
  ↓
Store binary
  ↓
Create media record
  ↓
Return selectable asset
```

## Delete

Require permission, confirmation, reference behavior and logging for important destructive actions.

## Form errors

Preserve user input and show field-level errors where possible.
