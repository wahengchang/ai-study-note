# CMS Permissions

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

| Capability | Editor | Admin | Super Admin |
|---|---:|---:|---:|
| View CMS | ✅ | ✅ | ✅ |
| Create content | ✅ | ✅ | ✅ |
| Edit content | ✅ | ✅ | ✅ |
| Upload media | ✅ | ✅ | ✅ |
| Publish content | TBD | ✅ | ✅ |
| Delete/archive content | TBD | ✅ | ✅ |
| Manage navigation | ❌ | ✅ | ✅ |
| Manage SEO defaults | ❌ | ✅ | ✅ |
| Manage users | ❌ | ✅ | ✅ |
| Assign roles | ❌ | ✅ | ✅ |
| Define permissions | ❌ | ❌ | ✅ |
| System settings | ❌ | TBD | ✅ |

## Rules

- Backend enforces every protected action.
- Prefer permission checks over hard-coded role-name checks.
- Super Admin should be rare.
- Deactivation should revoke CMS access promptly.
