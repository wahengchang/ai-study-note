# Content Publishing

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Proposed states

```text
draft
published
archived
```

### Draft
- CMS-visible
- Authorized preview only
- Not in public API
- Not in sitemap

### Published
- Publicly queryable
- Included in relevant listings
- May be included in sitemap
- Has `published_at`

### Archived
- Not public
- Retained for history/reference

## Publish validation
- title present
- slug valid/unique
- required body present
- taxonomy requirements satisfied
- media references valid
- required SEO fields valid

## Preview

Preview must be protected from indexing and unauthorized access.

## Future scheduling

Scheduling requires explicit schedule fields plus a reliable execution mechanism; do not implement it only as a UI timestamp.
