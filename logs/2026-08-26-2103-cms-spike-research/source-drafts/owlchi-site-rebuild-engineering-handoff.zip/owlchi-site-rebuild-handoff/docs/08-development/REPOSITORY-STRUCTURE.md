# Repository Structure

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Proposed monorepo

```text
repo/
├── apps/
│   ├── web/               # public website
│   ├── cms/               # admin CMS
│   └── api/               # backend/API
│
├── packages/
│   ├── database/          # schema/migrations/data access
│   ├── storage/           # storage adapter
│   ├── auth/              # auth contracts/utilities
│   ├── types/             # shared safe contracts
│   └── ui/                # optional shared primitives
│
├── docs/
├── scripts/
├── .env.example
└── README.md
```

This is proposed, not a framework requirement.

## Boundary rules

- `web` cannot import server secrets.
- `cms` cannot bypass API to write database.
- `api` owns write authorization.
- database/storage packages do not depend on presentation apps.
- shared packages exist only for genuinely shared concepts.

## Multiple repos

If separate repositories are selected, document ownership, version/contracts, local startup and coordinated releases.
