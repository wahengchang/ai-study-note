# Testing Strategy

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Unit
Good for:
- validation
- slug rules
- permission evaluation
- transformations
- domain logic

## Integration
Good for:
- repositories/database
- API + database
- storage adapter
- authentication
- publish/unpublish

## E2E — critical journey

1. Admin logs in.
2. Creates article.
3. Uploads/selects media.
4. Publishes.
5. Public site displays it.
6. Admin unpublishes.
7. Public site no longer exposes it.

## Launch-critical coverage
- draft leakage prevention
- authorization failure
- duplicate slug
- invalid upload
- real 404
- publish flow
- migration sanity

## CI

CI should fail on test, typecheck/lint if adopted, or build failures.
