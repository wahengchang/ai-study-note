# Troubleshooting

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

This file should evolve from real incidents, not speculative noise.

## Cannot start application
Check:
1. Runtime/package manager version
2. `.env`
3. Database connectivity
4. Storage connectivity
5. Migrations
6. Port conflicts

## CMS login loop
Check:
- cookie domain/path
- secure/same-site settings
- CMS/API origins
- proxy headers
- session store
- system clock

## Media upload fails
Check:
- size limits
- MIME validation
- storage credentials
- bucket/container
- CORS if direct upload
- public delivery config

## Content unexpectedly 404
Check:
- slug
- publication state
- published timestamp
- route namespace
- cache
- environment/database

## Migration fails

Do not manually edit production schema as first response. Capture migration/version, inspect state, determine partial application, recover according to migration tool behavior, and document the incident.
