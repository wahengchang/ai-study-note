# Local Development

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Goal

A new engineer should be able to clone the repository and reach a working Website + CMS + Backend without undocumented machine-specific steps.

## Expected flow

Exact commands depend on selected stack, but the repository should eventually support:

```bash
git clone <repository>
cd <repository>
cp .env.example .env
<install dependencies>
<start local database/storage>
<run migrations>
<seed development data>
<start services>
```

## Decision required
- runtime/package manager
- database implementation
- storage implementation/emulator
- container usage

## Seed data

Provide:
- one admin
- one editor
- sample page
- sample article/category/tag
- sample media where practical

## Onboarding definition of done

A clean machine can:
1. Start services.
2. Log into CMS.
3. Create a draft article.
4. Upload media.
5. Publish article.
6. View it publicly.
7. Run tests.
