# Coding Guidelines

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Principles

1. Optimize for maintainability and clear boundaries.
2. Use explicit domain names over generic abstractions.
3. Keep business rules out of UI event handlers.
4. Validate data at boundaries.
5. Centralize authorization logic.
6. Every schema change uses a migration.
7. Every new environment variable updates `.env.example` and docs.
8. Every architecture-level decision gets an ADR.
9. Update handoff/current-state docs when responsibility or project state changes.

## Errors
- Categorize application errors.
- Do not expose raw database/storage errors publicly.
- Log useful context without leaking secrets.

## Comments

Explain why, constraints and non-obvious tradeoffs—not obvious code.

## Dependencies

Before adding one, check maintenance, license, security posture and whether it actually reduces complexity.
