# Documentation Index

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Purpose

This directory is the source of truth for product intent, system boundaries, architecture, data, APIs, CMS behavior, infrastructure, development workflow and engineering handoff.

## Reading paths

### New engineer — orientation

1. `01-product/PRODUCT-OVERVIEW.md`
2. `01-product/FEATURE-MAP.md`
3. `02-architecture/SYSTEM-ARCHITECTURE.md`
4. `03-data/CONTENT-MODEL.md`
5. `08-development/REPOSITORY-STRUCTURE.md`
6. `10-handoff/CURRENT-STATE.md`
7. `10-handoff/HANDOFF.md`

### Implementing a feature

Read the product scope, relevant architecture document, relevant data model, API contract, CMS workflow and any related ADRs.

### Deploying or operating

Read:

- `07-infrastructure/ENVIRONMENTS.md`
- `07-infrastructure/CONFIGURATION.md`
- `07-infrastructure/DEPLOYMENT.md`
- `07-infrastructure/BACKUP-RESTORE.md`
- `07-infrastructure/MONITORING.md`

## Document status language

- **Defined** — intended behavior is clear enough to implement.
- **Proposed** — recommended default, still changeable.
- **TBD** — information is intentionally not invented.
- **Decision Required** — implementation should not proceed past the affected boundary until resolved.
- **Out of Scope** — deliberately excluded from V1.

## System domains

```text
Product
├── Public Website
├── CMS
├── Identity & Permissions
├── Content
├── Media
└── SEO

Platform
├── Backend / API
├── Database
├── Storage
├── Deployment
├── Monitoring
└── Backup
```
