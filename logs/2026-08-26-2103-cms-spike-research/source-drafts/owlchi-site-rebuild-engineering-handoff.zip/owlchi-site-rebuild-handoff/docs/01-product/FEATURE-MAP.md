# Feature Map

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

```text
Website Platform
│
├── Public Website
│   ├── Home
│   ├── Pages
│   ├── Articles
│   │   ├── Listing
│   │   ├── Detail
│   │   ├── Category
│   │   └── Tags
│   ├── Search
│   ├── Navigation
│   ├── Media Rendering
│   ├── SEO
│   └── Error States
│
├── CMS
│   ├── Authentication
│   ├── Dashboard
│   ├── Pages
│   ├── Articles
│   ├── Categories
│   ├── Tags
│   ├── Media Library
│   ├── Navigation
│   ├── SEO
│   ├── Users
│   ├── Roles & Permissions
│   └── Settings
│
├── Backend
│   ├── Public API
│   ├── Admin API
│   ├── Content Service
│   ├── Media Service
│   ├── Auth Service
│   └── Settings Service
│
├── Data
│   ├── Database
│   └── Object Storage
│
└── Operations
    ├── Environments
    ├── Deployment
    ├── Backup
    ├── Logs
    └── Monitoring
```

## Priority

**P0 launch:** public content rendering, CMS login, page/article CRUD, media upload, publish/unpublish, database/storage, SEO, deployment, backup.

**P1 expected:** categories/tags, navigation, users/roles, search, monitoring, redirects.

**P2 later:** scheduling, revisions, advanced search, approval workflow, analytics.
