# Product Overview

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Product statement

Build a maintainable content website platform that allows internal staff to create and manage structured content and media through a CMS, then publish that content to a fast, SEO-friendly public website.

## Primary users

| User | Goal |
|---|---|
| Visitor | Discover, browse, search and read public content |
| Editor | Create, edit, preview and publish content |
| Admin | Manage content, media, navigation, SEO and users |
| Super Admin | Manage system-level permissions and settings |

## Core product loop

```text
Editor
  ↓
Create / Edit
  ↓
Preview
  ↓
Publish
  ↓
Public Website
  ↓
Visitor consumes content
```

## System boundary

The product owns:

- Public page rendering
- Content management
- Media management
- Navigation
- SEO metadata
- CMS authentication
- Role-based permissions
- Persistent structured content
- Persistent media files

Not implied by V1:

- E-commerce
- Payments
- CRM
- Native mobile apps
- Multi-tenant SaaS
- Full DAM/MAM platform
- Advanced workflow engine
- AI content generation

## Product principles

1. Content is structured, not hard-coded into templates.
2. Public delivery and internal authoring are separate concerns.
3. Database stores structured records; object storage stores binary files.
4. Published state is explicit.
5. SEO is a first-class product capability.
6. Documentation and handoff are part of the deliverable.
