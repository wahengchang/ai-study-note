# User Roles

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## Visitor

Unauthenticated public user.

Can:
- View published content
- Browse categories
- Search public content
- Access public media

Cannot:
- View drafts
- Enter CMS
- Modify content

## Editor

Can normally:
- Create/edit pages and articles
- Upload/select media
- Manage taxonomy as permitted
- Preview content
- Publish if policy allows

## Admin

Can normally:
- Perform Editor actions
- Publish/archive/delete content
- Manage navigation
- Manage SEO defaults
- Manage users/roles within policy
- Manage site settings

## Super Admin

Can:
- Perform all Admin actions
- Define role/permission relationships
- Change security-sensitive/system settings
- Perform emergency administration

## Proposed permission model

```text
User
  ↓
Role
  ↓
Permission
  ↓
Resource + Action
```

Examples:
- `page.read`
- `page.create`
- `page.update`
- `page.publish`
- `page.delete`
- `media.upload`
- `navigation.manage`
- `user.manage`
- `settings.manage`

## Decision required

Decide whether Editors can publish directly or need Admin approval. Keep editing and publishing permissions separable either way.
