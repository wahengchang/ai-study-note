# Product Scope

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

## V1 — In scope

### Public website
- Home page
- Static/content pages
- Article listing and detail
- Category listing
- Search entry point
- Navigation
- Responsive layout
- SEO metadata
- Sitemap and robots
- 404/error states

### CMS
- Secure login
- Dashboard
- Page CRUD
- Article CRUD
- Category CRUD
- Tag CRUD
- Media upload and library
- Navigation management
- SEO fields
- Draft/published states
- User and role management
- Basic site settings

### Platform
- Backend API
- Relational database
- Object/file storage
- Environment configuration
- Database migrations
- Backup and restore procedure
- Logging/monitoring baseline

## V1 — Out of scope unless approved

- Payment processing
- E-commerce
- Customer account area
- Real-time collaboration
- Complex approval chains
- Multi-tenant architecture
- Video transcoding
- Full revision-control history
- Advanced DAM
- AI generation/personalization

## Future candidates

- Scheduled publishing
- Revision history
- Approval workflow
- Localization
- Advanced search
- Analytics
- CDN image transforms
- Webhooks
- Import/export
- AI tagging/summaries

## Scope change rule

Any feature that adds a persistent entity, external service, security boundary or operational dependency must update relevant product, architecture, data/API and ADR docs.
