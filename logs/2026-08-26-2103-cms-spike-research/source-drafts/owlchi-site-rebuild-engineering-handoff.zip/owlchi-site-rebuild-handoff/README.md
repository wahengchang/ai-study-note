# Owlchi-like Site System — Engineering Handoff Package

> Status: Draft for engineering handoff  
> Last updated: 2026-08-25  
> Reference product: https://github.com/wahengchang/owlchi-site-system/  
> Important: the reference repository implementation was not verified while preparing this package. Unless explicitly marked otherwise, these documents define the target rebuild rather than claiming facts about the existing codebase.

This package defines a clean rebuild of a content-driven website platform with:

- Public frontend website
- Admin backend / CMS
- Backend API / application services
- Relational database
- File / media storage
- Authentication and permissions
- Deployment, backup, monitoring and handoff conventions

## Start here

Read in this order:

1. `docs/00-README.md`
2. `docs/01-product/PRODUCT-OVERVIEW.md`
3. `docs/01-product/FEATURE-MAP.md`
4. `docs/02-architecture/SYSTEM-ARCHITECTURE.md`
5. `docs/03-data/CONTENT-MODEL.md`
6. `docs/08-development/LOCAL-DEVELOPMENT.md`
7. `docs/10-handoff/CURRENT-STATE.md`
8. `docs/10-handoff/HANDOFF.md`
9. `docs/10-handoff/DECISIONS-REQUIRED.md`

## Handoff rule

Do not convert a `TBD`, `Proposed`, or `Decision Required` item into an implementation assumption without recording the resulting decision in `docs/09-decisions/`.

## Target system at a glance

```text
Visitor
  |
  v
Public Website
  |
  v
Backend / API
  |-------------------|
  v                   v
Database           Object Storage
  ^                   ^
  |-------------------|
          |
        CMS
          ^
          |
     Editor / Admin
```
